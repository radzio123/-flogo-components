// Package readfile implements a file reader for Flogo
package filelist
